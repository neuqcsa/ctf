<?php
echo'<!--YOU HAVE MY \'name\'-->';
error_reporting(0);
$file=$_GET['name'].'.php';
if (preg_match("/phar|zip|bzip2|zlib|data|input|%00/i",$file)) {
	        echo('no way!');
		        exit;
		    }

if(!file_exists($file)){
    	echo $file." not exists!";
}
include($file);
?>

